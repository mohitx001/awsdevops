age = 21
if age < 4:
	ticket_price = 0
elif age < 18:
	ticket_price = 10
else:
	ticket_price = 15

print("ticket_price value is",ticket_price)
