def greet_user(username):
    print("Hello, " + username + "!")


# Function call
greet_user("AWS")
greet_user("DevOps")
