name = input("What's your name? ")
print("Hello, ",name)
