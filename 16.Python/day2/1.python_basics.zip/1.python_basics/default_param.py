def create_s3_bucket(bktname='mys3bucket'):
    print("Creating a " + bktname + " S3 bucket!")

create_s3_bucket()
create_s3_bucket('news3bucket')
