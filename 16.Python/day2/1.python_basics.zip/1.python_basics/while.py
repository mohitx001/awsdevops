current_value = 1
while current_value <= 5:
	print(current_value)
	current_value += 1
