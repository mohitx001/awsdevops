def add_numbers(x, y):
    return x + y

sum1 = add_numbers(3, 5)
sum2 = add_numbers(10, 15)
print("Value of sum1",sum1)
print("Value of sum2",sum2)